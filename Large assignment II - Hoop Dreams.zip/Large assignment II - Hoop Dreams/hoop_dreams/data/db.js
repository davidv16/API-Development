const mongoose = require('mongoose')
const pickupGameSchema = require('./schemas/pickupGameSchema')
const playerSchema = require('./schemas/playerSchema')
const pickupGamePlayersSchema = require('./schemas/pickupGamePlayersSchema')

const connectionString = 'mongodb+srv://ufo-user:1234@hoop-dreams.3qwuv.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'

const connection = mongoose.createConnection(connectionString, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})

const PickupGame = connection.model('PickupGame', pickupGameSchema)
const Player = connection.model('Player', playerSchema)
const PickupGamePlayers = connection.model('PickupGamePlayers', pickupGamePlayersSchema)

module.exports = {
  connection,
  PickupGame,
  PickupGamePlayers,
  Player
}
