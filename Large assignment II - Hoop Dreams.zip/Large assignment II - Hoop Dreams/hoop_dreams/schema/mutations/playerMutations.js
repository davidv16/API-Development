module.exports = `
  createPlayer(input: PlayerInput!): Player!
  updatePlayer(id: String! name: String!): Player!
  removePlayer(id: String!): Boolean!
`
