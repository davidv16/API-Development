module.exports = `
  scalar Moment
`
