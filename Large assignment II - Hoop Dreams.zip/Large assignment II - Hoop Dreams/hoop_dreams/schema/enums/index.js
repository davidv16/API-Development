const basketballFieldStatus = require('./basketballFieldStatus')

module.exports = `
  ${basketballFieldStatus}
`
