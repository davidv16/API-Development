module.exports = `
  enum BasketballFieldStatus {
    OPEN
    CLOSED
  }
`
