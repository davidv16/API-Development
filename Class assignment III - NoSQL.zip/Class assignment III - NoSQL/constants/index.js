module.exports = {
    // Shark species
    TIGER_SHARK: 'tiger shark',
    BULL_SHARK: 'bull shark',
    GREAT_WHITE_SHARK: 'great white shark',
    HAMMERHEAD_SHARK: 'hammerhead shark',
    WHALE_SHARK: 'whale shark',

    // Regions
    NORTH_AMERICA: 'north america',
    AUSTRALIA: 'australia',
    EUROPE: 'europe',

    // Areas
    MEXICO_BEACH: 'Mexico beach',
    MALIBU_BEACH: 'Malibu beach',
    GOLD_COAST: 'Gold coast',
    BONDI_BEACH: 'Bondi beach',
    REYKJANES_BEACH: 'Reykjanes beach'
};
