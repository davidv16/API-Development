namespace Datafication.Models.InputModels
{
    public class CategoryInputModel
    {
        public string Name { get; set; }
        public int? ParentCategoryId { get; set; }
    }
}